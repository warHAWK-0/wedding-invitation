import { useCallback, useEffect, useRef, useState } from 'react'
import { AnimatePresence, MotionConfig } from 'framer-motion'
import { Volume2, VolumeX } from 'lucide-react'

import EnvelopeIntro from './components/EnvelopeIntro'
import HeroSlide from './components/HeroSlide'
import CountdownSlide from './components/CountdownSlide'
import EventCards from './components/EventCards'
import FinalSlide from './components/FinalSlide'
import ProgressRail from './components/ProgressRail'
import useInviteAudio from './hooks/useInviteAudio'
import { EVENTS } from './data/wedding'

const TOTAL_SLIDES = 2 + EVENTS.length + 1 // hero + countdown + events + final

export default function App() {
  const [open, setOpen] = useState(
    () => sessionStorage.getItem('sv-invite-open') === 'true'
  )
  const [index, setIndex] = useState(0)
  const [offsets, setOffsets] = useState({})
  const scroller = useRef(null)
  const ticking = useRef(false)

  const { startSeal, startInner, toggleMute, muted, hasAudio } = useInviteAudio()

  const handleOpen = useCallback(() => {
    startInner() // must fire inside the tap, or mobile blocks playback
    setTimeout(() => {
      sessionStorage.setItem('sv-invite-open', 'true')
      setOpen(true)
    }, 400)
  }, [startInner])

  /* Track which slide is showing, and drift each plate slightly
     against the scroll so the illustrated world has some depth. */
  const onScroll = useCallback(() => {
    if (ticking.current) return
    ticking.current = true
    requestAnimationFrame(() => {
      const el = scroller.current
      ticking.current = false
      if (!el) return

      const h = el.clientHeight || 1
      setIndex(Math.round(el.scrollTop / h))

      const next = {}
      EVENTS.forEach((e, i) => {
        const slideTop = (i + 2) * h
        const delta = (el.scrollTop - slideTop) / h
        if (Math.abs(delta) < 1.6) next[e.id] = delta * 26
      })
      setOffsets(next)
    })
  }, [])

  useEffect(() => {
    const el = scroller.current
    if (!el) return
    el.addEventListener('scroll', onScroll, { passive: true })
    return () => el.removeEventListener('scroll', onScroll)
  }, [onScroll])

  return (
    <MotionConfig reducedMotion="user">
      <div className="snap" ref={scroller} data-locked={!open}>
        <HeroSlide offset={offsets.hero || 0} />
        <CountdownSlide />
        <EventCards offsets={offsets} />
        <FinalSlide />
      </div>

      <AnimatePresence>
        {!open && (
          <EnvelopeIntro
            key="envelope"
            onFirstTouch={startSeal}
            onOpen={handleOpen}
          />
        )}
      </AnimatePresence>

      {open && <ProgressRail index={index} total={TOTAL_SLIDES} />}

      {open && hasAudio && (
        <button
          className="icon-btn"
          onClick={toggleMute}
          aria-label={muted ? 'Unmute music' : 'Mute music'}
          style={{
            right: 'max(16px, env(safe-area-inset-right))',
            bottom: 'max(16px, env(safe-area-inset-bottom))',
          }}
        >
          {muted ? (
            <VolumeX size={16} strokeWidth={1.5} />
          ) : (
            <Volume2 size={16} strokeWidth={1.5} />
          )}
        </button>
      )}
    </MotionConfig>
  )
}
