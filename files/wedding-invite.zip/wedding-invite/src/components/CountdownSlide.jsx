import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import Frame from './Frame'
import { COUNTDOWN_TARGET } from '../data/wedding'

const TARGET = new Date(COUNTDOWN_TARGET)

function remaining() {
  const diff = TARGET - new Date()
  if (diff <= 0) return null
  return {
    days: Math.floor(diff / 86400000),
    hours: Math.floor((diff % 86400000) / 3600000),
    mins: Math.floor((diff % 3600000) / 60000),
    secs: Math.floor((diff % 60000) / 1000),
  }
}

export default function CountdownSlide() {
  const [t, setT] = useState(remaining)

  useEffect(() => {
    const id = setInterval(() => setT(remaining()), 1000)
    return () => clearInterval(id)
  }, [])

  return (
    <section
      className="slide"
      aria-label="Countdown to the wedding"
      style={{
        justifyContent: 'center',
        background:
          'radial-gradient(110% 70% at 50% 30%, #fbf6ea 0%, #f1e7d2 60%, #e2d0ae 100%)',
      }}
    >
      <Frame />

      <div
        style={{
          position: 'relative',
          zIndex: 2,
          padding: '0 34px',
          textAlign: 'center',
        }}
      >
        {t ? (
          <>
            <p className="eyebrow" style={{ marginBottom: 30 }}>
              Until we gather
            </p>

            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(4, 1fr)',
                gap: 4,
              }}
            >
              {[
                ['Days', t.days],
                ['Hours', t.hours],
                ['Min', t.mins],
                ['Sec', t.secs],
              ].map(([label, value], i) => (
                <div
                  key={label}
                  style={{
                    padding: '0 2px',
                    borderLeft: i === 0 ? 0 : '1px solid rgba(165,135,44,0.28)',
                  }}
                >
                  <div
                    style={{
                      fontSize: 'clamp(34px, 10vw, 46px)',
                      fontWeight: 300,
                      lineHeight: 1,
                      fontVariantNumeric: 'tabular-nums',
                      color: 'var(--ink)',
                    }}
                  >
                    {String(value).padStart(2, '0')}
                  </div>
                  <div
                    style={{
                      marginTop: 9,
                      fontSize: 9.5,
                      letterSpacing: '0.22em',
                      textTransform: 'uppercase',
                      color: 'var(--ink-soft)',
                    }}
                  >
                    {label}
                  </div>
                </div>
              ))}
            </div>

            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2, delay: 0.4 }}
              style={{
                marginTop: 34,
                fontSize: 17,
                fontStyle: 'italic',
                fontWeight: 300,
                color: 'var(--ink-soft)',
                lineHeight: 1.6,
              }}
            >
              Two days, six ceremonies,
              <br />
              one family growing larger.
            </motion.p>
          </>
        ) : (
          <p
            style={{
              fontSize: 25,
              fontStyle: 'italic',
              fontWeight: 300,
              color: 'var(--ink)',
              lineHeight: 1.5,
            }}
          >
            Thank you for celebrating
            <br />
            with us.
          </p>
        )}
      </div>
    </section>
  )
}
