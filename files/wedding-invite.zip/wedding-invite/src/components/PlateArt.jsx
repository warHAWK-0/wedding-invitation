import { useId, useState } from 'react'

/* Renders the illustrated plate.
   Until the artwork exists, it falls back to a soft wash built from
   that scene's palette — so the site is shareable before the
   Runway plates are approved. Drop the jpg in and it takes over. */
export default function PlateArt({ src, wash, dark, offset = 0 }) {
  const grainId = `grain-${useId().replace(/:/g, '')}`
  const [ok, setOk] = useState(Boolean(src))
  const [a, b, c] = wash

  return (
    <div className="plate">
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: `radial-gradient(120% 80% at 50% 8%, ${a} 0%, ${b} 52%, ${c} 100%)`,
        }}
      />

      {src && ok && (
        <img
          className="plate__img"
          src={src}
          alt=""
          onError={() => setOk(false)}
          style={{ transform: `translate3d(0, ${offset}px, 0) scale(1.08)` }}
        />
      )}

      {/* paper grain, straight from the master frame's texture */}
      <svg className="plate__grain" aria-hidden="true">
        <filter id={grainId}>
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter={`url(#${grainId})`} opacity="0.16" />
      </svg>

      <div
        className="plate__scrim"
        style={{
          background: dark
            ? 'linear-gradient(to top, rgba(18,20,32,0.92) 0%, rgba(18,20,32,0.55) 34%, rgba(18,20,32,0.05) 62%)'
            : 'linear-gradient(to top, rgba(46,36,24,0.86) 0%, rgba(46,36,24,0.42) 34%, rgba(46,36,24,0) 62%)',
        }}
      />
    </div>
  )
}
