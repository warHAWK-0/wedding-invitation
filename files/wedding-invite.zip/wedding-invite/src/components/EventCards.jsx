import { motion } from 'framer-motion'
import { MapPin } from 'lucide-react'
import PlateArt from './PlateArt'
import Frame from './Frame'
import { EVENTS } from '../data/wedding'

/* Every ceremony slide is drawn from this one component.
   Details are set as a ruled ledger rather than icon cards — it reads
   the way the printed card would, and keeps the plate art breathing. */
export default function EventCards({ offsets = {} }) {
  return (
    <>
      {EVENTS.map((e) => (
        <EventSlide key={e.id} event={e} offset={offsets[e.id] || 0} />
      ))}
    </>
  )
}

function EventSlide({ event, offset }) {
  const light = event.dark ? '#f4efe3' : 'var(--ivory)'

  return (
    <section className="slide" id={event.id} aria-label={event.en}>
      <PlateArt
        src={event.plate}
        wash={event.wash}
        dark={event.dark}
        offset={offset}
      />
      <Frame color="rgba(247,241,227,0.42)" />

      <div className="copy" style={{ color: light }}>
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
        >
          <p
            className="eyebrow"
            style={{ color: 'var(--gold-light)', marginBottom: 12 }}
          >
            {event.eyebrow}
          </p>

          <p
            className="deva"
            style={{ fontSize: 19, opacity: 0.88, marginBottom: 2 }}
          >
            {event.hi}
          </p>

          <h2
            className="display"
            style={{ fontSize: 'clamp(38px, 11vw, 54px)' }}
          >
            {event.en}
          </h2>

          <p
            style={{
              margin: '16px 0 22px',
              fontSize: 15.5,
              fontStyle: 'italic',
              fontWeight: 300,
              lineHeight: 1.6,
              opacity: 0.86,
              maxWidth: '32ch',
            }}
          >
            {event.note}
          </p>

          <dl style={{ display: 'grid', gap: 0 }}>
            <Row label={event.day} value={event.date} light={light} />
            <Row label="Time" value={event.time} light={light} />
            <Row
              label="Venue"
              value={
                <>
                  {event.venue.name}
                  <span style={{ display: 'block', opacity: 0.68, fontSize: 13 }}>
                    {event.venue.area}
                  </span>
                </>
              }
              light={light}
            />
          </dl>

          <a
            className="btn"
            href={event.venue.maps}
            target="_blank"
            rel="noreferrer"
            style={{
              marginTop: 22,
              color: light,
              borderColor: 'rgba(247,241,227,0.45)',
            }}
          >
            <MapPin size={14} strokeWidth={1.5} aria-hidden="true" />
            View map
          </a>
        </motion.div>
      </div>
    </section>
  )
}

function Row({ label, value, light }) {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: '78px 1fr',
        gap: 14,
        padding: '11px 0',
        borderTop: `1px solid ${
          light === 'var(--ivory)'
            ? 'rgba(247,241,227,0.24)'
            : 'rgba(244,239,227,0.22)'
        }`,
        alignItems: 'baseline',
      }}
    >
      <dt
        style={{
          fontSize: 9.5,
          letterSpacing: '0.2em',
          textTransform: 'uppercase',
          opacity: 0.62,
        }}
      >
        {label}
      </dt>
      <dd style={{ fontSize: 15.5, lineHeight: 1.45 }}>{value}</dd>
    </div>
  )
}
