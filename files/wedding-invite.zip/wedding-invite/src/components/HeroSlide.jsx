import { motion } from 'framer-motion'
import PlateArt from './PlateArt'
import Frame from './Frame'
import { COUPLE } from '../data/wedding'

/* Slide 1 after the envelope: who is inviting, and who for.
   The two names are the only moment of real scale on the site. */
export default function HeroSlide({ offset }) {
  return (
    <section className="slide" aria-label="Suraj and Varsha">
      <PlateArt
        src="/plates/hero.jpg"
        wash={['#f8f2e5', '#e6dcc4', '#c8b291']}
        offset={offset}
      />
      <Frame color="rgba(247,241,227,0.5)" />

      <div className="copy" style={{ color: 'var(--ivory)', paddingBottom: 64 }}>
        <motion.p
          className="deva"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 0.9 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          style={{ fontSize: 15, color: 'var(--gold-light)', marginBottom: 4 }}
        >
          {COUPLE.family.hi}
        </motion.p>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.15 }}
          style={{
            fontSize: 16.5,
            fontStyle: 'italic',
            fontWeight: 300,
            opacity: 0.92,
            lineHeight: 1.5,
            maxWidth: '30ch',
          }}
        >
          {COUPLE.family.en} invite you to the wedding of
        </motion.p>

        <motion.h1
          className="display"
          initial={{ opacity: 0, x: -26 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.1, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          style={{ marginTop: 14 }}
        >
          {COUPLE.groom.en}
        </motion.h1>

        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, delay: 0.7 }}
          style={{
            transformOrigin: 'left',
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            margin: '10px 0',
          }}
        >
          <span style={{ height: 1, width: 44, background: 'var(--gold-light)' }} />
          <span style={{ fontSize: 20, fontStyle: 'italic', opacity: 0.85 }}>and</span>
          <span style={{ height: 1, flex: 1, background: 'var(--gold-light)', opacity: 0.4 }} />
        </motion.div>

        <motion.h1
          className="display"
          initial={{ opacity: 0, x: 26 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.1, delay: 0.55, ease: [0.22, 1, 0.36, 1] }}
        >
          {COUPLE.bride.en}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 0.8 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 1 }}
          style={{
            marginTop: 22,
            fontSize: 14.5,
            letterSpacing: '0.16em',
            textTransform: 'uppercase',
          }}
        >
          {COUPLE.dateRange}
          <br />
          <span style={{ opacity: 0.7 }}>{COUPLE.city}</span>
        </motion.p>
      </div>
    </section>
  )
}
